## Commands:

-   `npm run build` - starts build procedure
-   `npm run dev` - starts build and run local server
